import { useCallback, useEffect, useMemo, useState } from "react";
import "./App.css";

const API = "http://localhost:5000/api";
const readToken = () => localStorage.getItem("campusfind_token") || "";

async function apiRequest(path, options = {}) {
  const token = readToken();
  const response = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {})
    }
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Something went wrong.");
  return data;
}

export default function App() {
  const [page, setPage] = useState("Home");
  const [user, setUser] = useState(null);
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [authForm, setAuthForm] = useState({ name: "", email: "", password: "" });
  const [itemForm, setItemForm] = useState({
    title: "", description: "", category: "Other", location: "", type: "Lost"
  });
  const [editingId, setEditingId] = useState(null);

  const showNotice = (message) => {
    setNotice(message);
  };

  const loadItems = useCallback(async (term = "") => {
    try {
      const query = term ? `?search=${encodeURIComponent(term)}` : "";
      const data = await apiRequest(`/items${query}`);
      setItems(data.items || []);
    } catch (error) {
      showNotice(`${error.message} Is the backend running?`);
    }
  }, []);

  useEffect(() => {
    loadItems();
    const token = readToken();
    if (token) {
      apiRequest("/auth/me")
        .then((data) => setUser(data.user))
        .catch(() => {
          localStorage.removeItem("campusfind_token");
          setUser(null);
        });
    }
  }, [loadItems]);

  useEffect(() => {
    const timer = setTimeout(() => loadItems(search), 250);
    return () => clearTimeout(timer);
  }, [search, loadItems]);

  const navigate = (nextPage) => {
    setNotice("");
    setPage(nextPage);
    if (nextPage !== "Report Item") setEditingId(null);
  };

  const submitAuth = async (event) => {
    event.preventDefault();
    setBusy(true);
    setNotice("");
    try {
      const endpoint = page === "Register" ? "/auth/register" : "/auth/login";
      const data = await apiRequest(endpoint, {
        method: "POST",
        body: JSON.stringify(authForm)
      });
      localStorage.setItem("campusfind_token", data.token);
      setUser(data.user);
      setAuthForm({ name: "", email: "", password: "" });
      setPage("Home");
      showNotice(`Welcome${data.user.name ? `, ${data.user.name}` : ""}!`);
    } catch (error) {
      showNotice(error.message);
    } finally {
      setBusy(false);
    }
  };

  const logout = () => {
    localStorage.removeItem("campusfind_token");
    setUser(null);
    setPage("Home");
    showNotice("You have logged out.");
  };

  const submitItem = async (event) => {
    event.preventDefault();
    if (!user) {
      showNotice("Please log in before reporting an item.");
      setPage("Login");
      return;
    }
    setBusy(true);
    setNotice("");
    try {
      if (editingId) {
        await apiRequest(`/items/${editingId}`, {
          method: "PUT",
          body: JSON.stringify(itemForm)
        });
        showNotice("Your report has been updated.");
      } else {
        await apiRequest("/items", {
          method: "POST",
          body: JSON.stringify(itemForm)
        });
        showNotice("Your report has been submitted.");
      }
      setItemForm({ title: "", description: "", category: "Other", location: "", type: "Lost" });
      setEditingId(null);
      await loadItems(search);
      setPage("Browse Items");
    } catch (error) {
      showNotice(error.message);
    } finally {
      setBusy(false);
    }
  };

  const myItems = useMemo(
    () => items.filter((item) => (item.owner?._id || item.owner?.id || item.owner) === user?.id),
    [items, user]
  );

  const editItem = (item) => {
    setItemForm({
      title: item.title || "",
      description: item.description || "",
      category: item.category || "Other",
      location: item.location || "",
      type: item.type || "Lost"
    });
    setEditingId(item._id);
    setPage("Report Item");
    setNotice("");
  };

  const updateStatus = async (item) => {
    try {
      await apiRequest(`/items/${item._id}`, {
        method: "PUT",
        body: JSON.stringify({ status: item.status === "Resolved" ? "Open" : "Resolved" })
      });
      await loadItems(search);
      showNotice("Item status updated.");
    } catch (error) {
      showNotice(error.message);
    }
  };

  const deleteItem = async (item) => {
    if (!window.confirm(`Delete "${item.title}"?`)) return;
    try {
      await apiRequest(`/items/${item._id}`, { method: "DELETE" });
      await loadItems(search);
      showNotice("Report deleted.");
    } catch (error) {
      showNotice(error.message);
    }
  };

  return (
    <div className="app-shell">
      <header className="navbar">
        <button className="brand" onClick={() => navigate("Home")} aria-label="CampusFind home">
          <span className="brand-mark">C</span>
          <span>Campus<span className="accent">Find</span></span>
        </button>
        <nav className="nav-links">
          <button onClick={() => navigate("Home")}>Home</button>
          <button onClick={() => navigate("Browse Items")}>Browse Items</button>
          {user && <button onClick={() => navigate("My Reports")}>My Reports</button>}
          <button className="nav-report" onClick={() => { setItemForm({ title: "", description: "", category: "Other", location: "", type: "Lost" }); navigate("Report Item"); }}>
            + Report Item
          </button>
          {user ? (
            <button className="nav-auth" onClick={logout}>Log out</button>
          ) : (
            <>
              <button onClick={() => navigate("Login")}>Login</button>
              <button className="nav-signup" onClick={() => navigate("Register")}>Sign Up</button>
            </>
          )}
        </nav>
      </header>

      {notice && (
        <div className="notice" role="status">
          <span>{notice}</span>
          <button onClick={() => setNotice("")} aria-label="Dismiss message">×</button>
        </div>
      )}

      <main>
        {page === "Home" && (
          <>
            <section className="hero">
              <div className="hero-copy">
                <span className="eyebrow"><span className="dot" /> SMART CAMPUS LOST & FOUND</span>
                <h1>Lost something?<br /><span>Let's find it.</span></h1>
                <p>A smarter way to report lost belongings and reunite students with the things that matter. Search campus reports or post an item you've found.</p>
                <div className="hero-actions">
                  <button className="primary-btn" onClick={() => navigate("Browse Items")}>Browse Items <span>→</span></button>
                  <button className="secondary-btn" onClick={() => { setItemForm({ title: "", description: "", category: "Other", location: "", type: "Lost" }); navigate("Report Item"); }}>Report an Item</button>
                </div>
                <div className="trust-row"><span>✓ Student-friendly</span><span>✓ Easy reporting</span><span>✓ Campus community</span></div>
              </div>
              <div className="hero-art" aria-hidden="true">
                <div className="art-circle circle-one" />
                <div className="art-circle circle-two" />
                <div className="floating-card card-top"><span className="art-icon">🎒</span><span><b>Lost backpack</b><small>Library · Today</small></span><i>Lost</i></div>
                <div className="search-illustration"><span>⌕</span></div>
                <div className="floating-card card-bottom"><span className="art-icon green">✓</span><span><b>Found & reported</b><small>Helping students reconnect</small></span></div>
              </div>
            </section>

            <section className="stats-row">
              <div><strong>{items.length}</strong><span>Community reports</span></div>
              <div><strong>{items.filter((item) => item.type === "Lost" && item.status !== "Resolved").length}</strong><span>Lost items</span></div>
              <div><strong>{items.filter((item) => item.type === "Found" && item.status !== "Resolved").length}</strong><span>Found items</span></div>
              <div><strong>{items.filter((item) => item.status === "Resolved").length}</strong><span>Resolved reports</span></div>
            </section>

            <section className="content-section">
              <div className="section-heading">
                <div><span className="eyebrow">THE CAMPUS BOARD</span><h2>Recently reported items</h2><p>Latest reports from your campus community.</p></div>
                <button className="link-btn" onClick={() => navigate("Browse Items")}>View all reports →</button>
              </div>
              <ItemGrid items={items.slice(0, 3)} onEdit={editItem} onStatus={updateStatus} onDelete={deleteItem} user={user} />
            </section>
          </>
        )}

        {page === "Browse Items" && (
          <section className="content-section page-content">
            <span className="eyebrow">CAMPUS COMMUNITY</span>
            <h1>Browse reports</h1>
            <p className="muted">Search lost and found reports submitted by students.</p>
            <input className="search-input" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by item, category, or location..." />
            <ItemGrid items={items} onEdit={editItem} onStatus={updateStatus} onDelete={deleteItem} user={user} />
            {items.length === 0 && <EmptyState text="No reports found yet. Be the first to report an item." />}
          </section>
        )}

        {page === "My Reports" && (
          <section className="content-section page-content">
            <span className="eyebrow">YOUR ACTIVITY</span>
            <h1>My reports</h1>
            <p className="muted">Manage the items you have reported.</p>
            <ItemGrid items={myItems} onEdit={editItem} onStatus={updateStatus} onDelete={deleteItem} user={user} />
            {myItems.length === 0 && <EmptyState text="You have not submitted any reports yet." />}
          </section>
        )}

        {page === "Report Item" && (
          <section className="form-layout">
            <div className="form-intro"><span className="eyebrow">MAKE A DIFFERENCE</span><h1>{editingId ? "Edit your report" : "Report an item"}</h1><p>Every report helps our campus community reconnect people with their belongings. Add clear details to help someone recognize their item.</p><div className="tip-card"><span>💡</span><div><b>Helpful tip</b><p>Include a specific campus location and a clear description. Avoid posting sensitive personal information.</p></div></div></div>
            <form className="form-card" onSubmit={submitItem}>
              <h2>Item details</h2>
              <p className="muted">Fields marked * are required.</p>
              <label>Is the item lost or found? *</label>
              <div className="choice-row">
                {["Lost", "Found"].map((type) => <button type="button" key={type} className={`choice ${itemForm.type === type ? "selected" : ""}`} onClick={() => setItemForm({ ...itemForm, type })}>{type === "Lost" ? "🔎" : "🎁"} {type}</button>)}
              </div>
              <label>Item name *</label>
              <input required maxLength={100} value={itemForm.title} onChange={(event) => setItemForm({ ...itemForm, title: event.target.value })} placeholder="e.g. Black wireless headphones" />
              <label>Category</label>
              <select value={itemForm.category} onChange={(event) => setItemForm({ ...itemForm, category: event.target.value })}>
                {["Other", "ID Card", "Books", "Electronics", "Clothing", "Bags", "Bottle", "Keys", "Accessories"].map((category) => <option key={category}>{category}</option>)}
              </select>
              <label>Campus location *</label>
              <input required maxLength={150} value={itemForm.location} onChange={(event) => setItemForm({ ...itemForm, location: event.target.value })} placeholder="e.g. Main library, second floor" />
              <label>Description</label>
              <textarea rows="4" maxLength={1000} value={itemForm.description} onChange={(event) => setItemForm({ ...itemForm, description: event.target.value })} placeholder="Describe the item, colour, brand, or other identifying details..." />
              <button className="primary-btn full-btn" disabled={busy}>{busy ? "Please wait..." : editingId ? "Save Changes →" : "Submit Report →"}</button>
              {editingId && <button type="button" className="secondary-btn full-btn" onClick={() => { setEditingId(null); setItemForm({ title: "", description: "", category: "Other", location: "", type: "Lost" }); navigate("My Reports"); }}>Cancel editing</button>}
              {!user && <p className="form-note">You will need to log in to submit a report.</p>}
            </form>
          </section>
        )}

        {(page === "Login" || page === "Register") && (
          <section className="auth-layout">
            <div className="auth-aside"><div className="auth-logo">C</div><span className="eyebrow">YOUR CAMPUS, CONNECTED</span><h1>Good things find their way back.</h1><p>Join your campus community and help lost belongings find their owners.</p></div>
            <form className="form-card auth-card" onSubmit={submitAuth}>
              <span className="eyebrow">{page === "Login" ? "WELCOME BACK" : "JOIN THE COMMUNITY"}</span>
              <h2>{page === "Login" ? "Log in to CampusFind" : "Create your account"}</h2>
              <p className="muted">{page === "Login" ? "Enter your details to continue." : "A few details to get started."}</p>
              {page === "Register" && <><label>Full name *</label><input required value={authForm.name} onChange={(event) => setAuthForm({ ...authForm, name: event.target.value })} placeholder="Your full name" /></>}
              <label>Email address *</label><input type="email" required value={authForm.email} onChange={(event) => setAuthForm({ ...authForm, email: event.target.value })} placeholder="you@example.com" />
              <label>Password * (minimum 6 characters)</label><input type="password" minLength={6} required value={authForm.password} onChange={(event) => setAuthForm({ ...authForm, password: event.target.value })} placeholder="Enter password" />
              <button className="primary-btn full-btn" disabled={busy}>{busy ? "Please wait..." : page === "Login" ? "Log In →" : "Create Account →"}</button>
              <p className="switch-auth">{page === "Login" ? "New to CampusFind?" : "Already have an account?"} <button type="button" onClick={() => { setNotice(""); setPage(page === "Login" ? "Register" : "Login"); }}> {page === "Login" ? "Sign up" : "Log in"}</button></p>
            </form>
          </section>
        )}
      </main>

      <footer className="footer"><div className="footer-brand"><span className="brand-mark">C</span><b>Campus<span className="accent">Find</span></b></div><p>Making campus lost and found simpler, together.</p><span>© 2026 CampusFind · Student project</span></footer>
    </div>
  );
}

function ItemGrid({ items, onEdit, onStatus, onDelete, user }) {
  if (!items.length) return null;
  return <div className="item-grid">{items.map((item) => {
    const ownerId = item.owner?._id || item.owner?.id || item.owner;
    const isOwner = user && String(ownerId) === String(user.id);
    const icon = item.category === "Books" ? "📚" : item.category === "ID Card" ? "🪪" : item.category === "Electronics" ? "🎧" : item.category === "Keys" ? "🔑" : item.category === "Bottle" ? "🧴" : item.category === "Bags" ? "🎒" : "📦";
    return <article className="item-card" key={item._id}>
      <div className="item-visual"><span className="item-emoji">{icon}</span><span className={`type-badge ${item.type.toLowerCase()}`}>{item.type}</span></div>
      <div className="item-body"><div className="item-category">{item.category || "Other"}</div><h3>{item.title}</h3><p className="item-description">{item.description || "No additional description provided."}</p><div className="item-location">📍 {item.location}</div><div className="item-bottom"><span className={`status ${item.status === "Resolved" ? "resolved" : ""}`}>{item.status || "Open"}</span><span className="item-date">{item.createdAt ? new Date(item.createdAt).toLocaleDateString() : "Just now"}</span></div>
      {isOwner && <div className="item-actions"><button onClick={() => onEdit(item)}>Edit</button><button onClick={() => onStatus(item)}>{item.status === "Resolved" ? "Reopen" : "Resolve"}</button><button className="delete-action" onClick={() => onDelete(item)}>Delete</button></div>}
      </div>
    </article>;
  })}</div>;
}

function EmptyState({ text }) {
  return <div className="empty-state"><span>🔎</span><h3>Nothing here yet</h3><p>{text}</p></div>;
}
