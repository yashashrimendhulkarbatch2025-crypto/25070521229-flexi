import mongoose from "mongoose";

const itemSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, default: "", trim: true },
    category: { type: String, default: "Other" },
    location: { type: String, required: true, trim: true },
    type: { type: String, enum: ["Lost", "Found"], required: true },
    status: { type: String, enum: ["Open", "Resolved"], default: "Open" },
    owner: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
  },
  { timestamps: true }
);

export default mongoose.model("Item", itemSchema);
