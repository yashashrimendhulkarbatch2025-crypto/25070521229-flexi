import { Router } from "express";
import Item from "../models/Item.js";
import auth from "../middleware/auth.js";

const router = Router();

// Public: list items. Optional query string ?search=...
router.get("/", async (req, res) => {
  try {
    const filter = {};
    if (req.query.search) {
      const escaped = String(req.query.search).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const regex = new RegExp(escaped, "i");
      filter.$or = [{ title: regex }, { description: regex }, { category: regex }, { location: regex }];
    }
    const items = await Item.find(filter)
      .populate("owner", "name")
      .sort({ createdAt: -1 })
      .limit(100);
    res.json({ items });
  } catch {
    res.status(500).json({ message: "Could not load items." });
  }
});

// Private: create item
router.post("/", auth, async (req, res) => {
  try {
    const { title, description, category, location, type } = req.body;
    if (!title?.trim() || !location?.trim() || !["Lost", "Found"].includes(type)) {
      return res.status(400).json({ message: "Title, location, and Lost/Found type are required." });
    }
    const item = await Item.create({
      title: title.trim(),
      description: description || "",
      category: category || "Other",
      location: location.trim(),
      type,
      owner: req.userId
    });
    await item.populate("owner", "name");
    res.status(201).json({ item });
  } catch {
    res.status(500).json({ message: "Could not create item." });
  }
});

// Private: update own item
router.put("/:id", auth, async (req, res) => {
  try {
    const item = await Item.findOne({ _id: req.params.id, owner: req.userId });
    if (!item) return res.status(404).json({ message: "Item not found or you do not own it." });

    const { title, description, category, location, type, status } = req.body;
    if (title !== undefined) item.title = title.trim();
    if (description !== undefined) item.description = description;
    if (category !== undefined) item.category = category;
    if (location !== undefined) item.location = location.trim();
    if (type !== undefined && ["Lost", "Found"].includes(type)) item.type = type;
    if (status !== undefined && ["Open", "Resolved"].includes(status)) item.status = status;

    await item.save();
    await item.populate("owner", "name");
    res.json({ item });
  } catch {
    res.status(400).json({ message: "Could not update item. Check the item ID and fields." });
  }
});

// Private: delete own item
router.delete("/:id", auth, async (req, res) => {
  try {
    const item = await Item.findOneAndDelete({ _id: req.params.id, owner: req.userId });
    if (!item) return res.status(404).json({ message: "Item not found or you do not own it." });
    res.json({ message: "Item deleted." });
  } catch {
    res.status(400).json({ message: "Could not delete item." });
  }
});

export default router;
