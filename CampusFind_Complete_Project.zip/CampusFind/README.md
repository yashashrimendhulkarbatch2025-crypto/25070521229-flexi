# CampusFind — Smart Campus Lost & Found

A beginner-friendly React + Express + MongoDB project.

## Requirements
- Node.js LTS
- MongoDB Community Server running locally
- VS Code

## 1. Open the project
Extract the ZIP. Open the `CampusFind` folder in VS Code.

## 2. Configure the backend
Open a terminal in VS Code:

```powershell
cd server
npm install
```

Copy `.env.example` to `.env`. The default local MongoDB URI is:
`mongodb://127.0.0.1:27017/campusfind`

Change `JWT_SECRET` in `.env` to a long random secret.

Start the backend:
```powershell
npm run dev
```
The API runs at `http://localhost:5000`.

Make sure MongoDB Community Server is running. You do not need MongoDB Atlas.

## 3. Configure the frontend
Open a SECOND terminal in VS Code:

```powershell
cd client
npm install
npm run dev
```

Open the exact Local URL printed by Vite, usually `http://localhost:5173`.

## Features
- Register and log in with a password hashed by bcrypt
- Browse lost/found reports
- Search reports
- Create reports (login required)
- Edit and delete your own reports
- Mark reports resolved
- Express REST API backed by local MongoDB

## Important
- Do not upload `server/.env` to GitHub.
- This is a student project starter, not a production-ready service.
- The frontend and backend run in separate terminals.
